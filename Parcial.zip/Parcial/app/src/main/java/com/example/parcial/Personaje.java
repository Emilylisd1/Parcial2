package com.example.parcial;

public class Personaje {
        private String name;
        private String status;
        private String description;
        private String imageUrl;

        public Personaje(String name, String status, String description, String imageUrl) {
            this.name = name;
            this.status = status;
            this.description = description;
            this.imageUrl = imageUrl;
        }

        public String getName() {
            return name;
        }

        public String getStatus() {
            return status;
        }

        public String getDescription() {
            return description;
        }

        public String getImageUrl() {
            return imageUrl;
        }
}
