package com.example.parcial;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity{
    private RecyclerView recyclerView;
    private CharacterAdapter characterAdapter;
    private List<Personaje> characterList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        characterList = new ArrayList<>();
        // Aquí deberías agregar personajes a characterList, con sus nombres, estados, descripciones e URLs de imagen

        characterAdapter = new CharacterAdapter(this, characterList);
        recyclerView.setAdapter(characterAdapter);
    }
}
